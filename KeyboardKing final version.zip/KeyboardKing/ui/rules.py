import tkinter as tk

from game.game import NUMBER_OF_ROUNDS


def show(parent):
    """Fuknce obstarává pravidla hry v horním menu"""
    rules_window = tk.Toplevel(parent)
    rules_window.title("Game Rules")
    rules_window.geometry("750x250")

    rules_window.transient(parent)
    rules_window.grab_set()

    rules_text = (
        "Game Rules:\n\n"
        "1. Rule 1: Six rectangles at the bottom of the screen represent the keys S, D, F, J, K, and L.\n"
        "2. Rule 2: When the circle is over the key, press the corresponding key on the keyboard as quickly as possible.\n"
        "3. Rule 3: A colored circle falls from the top of the screen, indicating the start of a round.\n"
        "4. Rule 4: When the circle reaches the bottom, a new round begins.\n"
        "5. Rule 5: You earn points by pressing the correct key before the circle moves over the next box.\n"
        "6. Rule 6: Once a key is pressed, it cannot be changed.\n"
        f"7. Rule 7: There are {NUMBER_OF_ROUNDS} rounds.\n"
        "Enjoy the game!"
    )
    label = tk.Label(rules_window, text=rules_text, justify="left", padx=10, pady=10)
    label.pack()

    close_button = tk.Button(rules_window, text="Close", command=rules_window.destroy)
    close_button.pack(pady=10)
