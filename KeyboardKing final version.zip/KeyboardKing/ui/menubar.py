from tkinter import Menu


def build(parent, new_game, show_rules, about):
    """Fukkce vytvoří hodní menu"""
    menubar = Menu(parent)

    game_menu = Menu(menubar, tearoff=0)
    game_menu.add_command(label="New Game", command=new_game)
    game_menu.add_separator()
    game_menu.add_command(label="Exit", command=parent.quit)
    menubar.add_cascade(label="Game", menu=game_menu)

    help_menu = Menu(menubar, tearoff=0)
    help_menu.add_command(label="Show Rules", command=show_rules)
    help_menu.add_command(label="About", command=about)
    menubar.add_cascade(label="Help", menu=help_menu)

    return menubar
