# Keyboard King
# Klávesová hra v programovacím jazyce Phyton
# peknaa@jirovcovka.net 

import tkinter as tk
from tkinter import PhotoImage

from game.game import Game
import ui.menubar as mb
import ui.rules as rules
import ui.about as about


class GameApp:
    def __init__(self, parent):
        self.root = parent
        self.root.title("Keyboard King")
        icon_image = PhotoImage(file="images/icon.png")
        self.root.iconphoto(True, icon_image)

        menubar = mb.build(self.root, self.new_game, self.show_rules, self.show_about)
        self.root.config(menu=menubar)

        self.game = Game(self.root)

        self.root.focus_force()

    def new_game(self):
        """Funkce zaolá fuknci, která spustí hru"""
        self.game.start()

    def show_rules(self):
        """Funkce zavolá funkci, která ukáže pravidla"""
        rules.show(self.root)

    def show_about(self):
        """Funkce zavolá jinou funkci, která ukáže informace o autorovi"""
        about.about(self.root)


if __name__ == "__main__":
    root = tk.Tk()
    app = GameApp(root)
    root.mainloop()
