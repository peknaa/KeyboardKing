from ui.game_canvas import GameCanvas

NUMBER_OF_ROUNDS = 5
# Initial delay (in miliseconds) between circle drops
STARTING_DELAY = 1000
# With each round the delay decreases by this amount of miliseconds
DELAY_DECREASE_PER_ROUND = 100


class Game:
    def __init__(self, parent):
        self.parent = parent
        self.canvas = GameCanvas(self)
        self.score = 0
        self.round_no = 1
        self.delay = STARTING_DELAY

        self.canvas.update_score(self.score)
        self.canvas.update_round(self.round_no, NUMBER_OF_ROUNDS)

    def start(self):
        self.score = 0
        self.canvas.update_score(self.score)
        self.round_no = 1
        self.canvas.update_round(self.round_no, NUMBER_OF_ROUNDS)
        self.canvas.countdown_and_start(3)

    def countdown_over(self):
        self.delay = STARTING_DELAY
        self.canvas.start_round(self.delay)

    def successful_key(self):
        self.score += 1
        self.canvas.update_score(self.score)

    def round_over(self):
        if self.round_no < NUMBER_OF_ROUNDS:
            self.round_no += 1
            self.canvas.update_round(self.round_no, NUMBER_OF_ROUNDS)
            self.delay -= DELAY_DECREASE_PER_ROUND
            self.canvas.start_round(self.delay)
        else:
            self.canvas.game_over()

    def hit(self):
        self.score += 1
        self.canvas.update_score(self.score)
