from tkinter import Toplevel
from tkinter import PhotoImage
from tkinter import Button
from tkinter import Label


def about(parent):
    about_window = Toplevel(parent)
    about_window.title("About")
    about_window.geometry("300x320")

    # Disable interaction with the main window while this modal is open
    about_window.transient(parent)
    about_window.grab_set()

    version_info = "Version: 1.0.0"
    author_info = "Author: Alžběta Pěkná"

    version_label = Label(about_window, text=version_info, font=("Arial", 10))
    version_label.pack(pady=10)
    author_label = Label(about_window, text=author_info, font=("Arial", 10))
    author_label.pack(pady=10)

    try:
        avatar_image = PhotoImage(file="images/avatar.png")
        avatar_label = Label(about_window, image=avatar_image)
        avatar_label.image = avatar_image
        avatar_label.pack(pady=10)
    except Exception as e:
        print(f"Error loading avatar: {e}")

    close_button = Button(about_window, text="Close", command=about_window.destroy)
    close_button.pack(pady=20)
