from random import randint
from tkinter import Canvas


def key_for_column(column):
    if column == 0:
        return "s"
    if column == 1:
        return "d"
    if column == 2:
        return "f"
    if column == 3:
        return "j"
    if column == 4:
        return "k"
    if column == 5:
        return "l"


class GameCanvas(Canvas):

    def __init__(self, game):
        self.game = game
        self.root = game.parent
        Canvas.__init__(self, self.root, width=900, height=800, bg="white")
        self.pack(fill="both", expand=True)
        self.root.bind("<Key>", self.key_pressed)

        self.countdown = None
        self.drop_delay = None
        self.circle_level = None
        self.circle_column = None
        self.listen_for_keys = False

        self.draw_rectangles()

    def draw_rectangles(self):
        for i in range(6):
            self.create_rectangle(100 + i * 120, 750, 200 + i * 120, 780,
                                  outline="black", fill="white", width=3)
            self.create_text(100 + i * 120 + 50, 765,
                             text=key_for_column(i), font=("Arial", 16), fill="black")

    def update_score(self, score):
        score_text = f"Score: {score}"
        self.delete("score")
        self.create_text(250, 40, text=score_text, font=("Arial", 36), fill="black", tags="score")

    def update_round(self, round_no, rounds_total):
        round_text = f"Round: {round_no} / {rounds_total}"
        self.delete("round")
        self.create_text(600, 40, text=round_text, font=("Arial", 36), fill="black", tags="round")

    def countdown_and_start(self, seconds):
        self.countdown = seconds
        self.draw_countdown()
        self.after(1000, self.next_countdown)

    def next_countdown(self):
        self.countdown -= 1
        self.draw_countdown()
        if self.countdown > 0:
            self.after(1000, self.next_countdown)
        else:
            self.game.countdown_over()

    def draw_countdown(self):
        self.delete("countdown")
        if self.countdown > 0:
            self.create_text(450, 400, text=self.countdown, font=("Arial", 72),
                             fill="gray", tags="countdown")

    def start_round(self, drop_delay):
        self.drop_delay = drop_delay
        self.circle_level = 0
        self.circle_column = randint(0, 5)
        self.draw_circle()
        self.listen_for_keys = True
        self.after(self.drop_delay, self.next_level)

    def draw_circle(self, color="grey"):
        self.delete("circle")
        if self.circle_level is not None:
            self.create_oval(100 + self.circle_column * 120, 100 + self.circle_level * 50,
                             200 + self.circle_column * 120, 200 + self.circle_level * 50,
                             outline="black", width=5, fill=color, tags="circle")

    def next_level(self):
        self.listen_for_keys = True
        if self.circle_level > 8:
            self.game.round_over()
        else:
            self.circle_level += 1
            self.circle_column = randint(0, 5)
            self.draw_circle()
            self.after(self.drop_delay, self.next_level)

    def game_over(self):
        self.circle_level = None
        self.listen_for_keys = False
        self.draw_circle()
        self.create_text(450, 400, text="Game over", font=("Arial", 72),
                         fill="gray", tags="countdown")

    def key_pressed(self, event):
        if not self.listen_for_keys:
            return

        if event.char == key_for_column(self.circle_column):
            self.game.hit()
            self.draw_circle(color="green")
        else:
            self.draw_circle(color="red")

        self.listen_for_keys = False
